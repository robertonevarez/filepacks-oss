Test run failed during pytest setup: scripts/update_package_cache.py tried to download packages required for tests but returned non-zero exit status. This environment may be offline or restricted, so tests that require network downloads cannot proceed.

See pytest_output.txt for full details.
